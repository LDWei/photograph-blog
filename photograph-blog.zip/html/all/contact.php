<?php 
// header("Content-type: text/html; charset=utf-8"); 
date_default_timezone_set('prc');
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '111111';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if (!$conn)
  {
  die('Could not connect: ' . mysql_error());
  }
$time=date('Y-m-d H:i:s');
mysql_select_db("contact", $conn);
mysql_query("SET NAMES 'utf8'");

//判断输入的名字，内容是否为空
// require('../jiaoben3850/lib/mysql.php');
// require('../jiaoben3850/lib/config.php');
// mConn();
$n['name']=trim($_POST['name']);
$m['message']=trim($_POST['message']);
if (empty($n['name'])||empty($m['message'])) {
		echo "名字或者内容不能为空";
		exit();		
    }
//不为空则存入表中
else
	{	
		$sql="INSERT INTO person (Name,Email,Address,Message,cdate)
    VALUES('$_POST[name]','$_POST[email]','$_POST[address]','$_POST[message]','$time')";

  if (!mysql_query($sql,$conn))
  {
  die('Error: ' . mysql_error());
  }
echo "<script>alert('留言成功');history.back();</script>";
   }
?>