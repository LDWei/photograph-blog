<!DOCTYPE html>
<html lang="en">
  <head>
  <link rel="icon" href="./img/logo.ico" type="image/x-icon"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="css/main.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>

    <title>摄影|时间</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Add custom CSS here -->
    <link href="css/slidefolio.css" rel="stylesheet">
	<!-- Font Awesome -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
  </head>
<body>

    <!-- Header Area -->
    <div id="top" class="header">
      <div class="vert-text">
	  <img class="img-rounded" alt="Company Logo" src="./img/logo.ico"/>
        <h2><em>摄影 | 时间</em></h2>
		 <ul class="list-inline">
              <li>welcome</li>
              <li>to</li>
              <li>photograph</li>
			  <li>|</li>
			   <li>time</li>
            </ul>	
			<br>
			<!-- <a href="#about" class="btn btn-top">开始吧</a> -->
      </div>
    </div>
    <!-- /Header Area -->
	  <div id="nav">
    <!-- Navigation -->
    <nav class="navbar navbar-new" role="navigation">
   <div class="container">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mobilemenu">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
	<a href="#" class="navbar-brand">摄影|时间</a>           

  </div>
  <div class="collapse navbar-collapse" id="mobilemenu">

	  <ul class="nav navbar-nav navbar-right text-center">
	    <li><a href="#top"><i class="service-icon fa fa-home"></i>&nbsp;首页</a></li>
        <li><a href="#about"><i class="service-icon fa fa-info"></i>&nbsp;记录</a></li>
        <li><a href="#services"><i class="service-icon fa fa-laptop"></i>&nbsp;学堂</a></li>
        <li><a href="#portfolio"><i class="service-icon fa fa-camera"></i>&nbsp;图片</a></li>
        <li><a href="#contact"><i class="service-icon fa fa-envelope"></i>&nbsp;留言</a></li>

    </ul>
  </div><!-- /.navbar-collapse -->
  </div>
</nav>
    <!-- /Navigation -->
</div>	
    <!-- About -->
    <div id="about" class="about_us">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 text-center">
            <h2 style="color:black">一张·照片</h2>
            <p class="lead" style="color:#4f4f4f">
            用  平和的心态,平常的视觉 记录,平淡的生活</p>
            <p class="lead" style="color:#4f4f4f">
            感谢  那些出现在我镜头里的人、物 一切皆是缘分.</p>
            <p class="lead" style="color:#4f4f4f">
            使然  一些零碎杂片就像一些凌乱的心情，总得时常梳理一下
            把它放在心底。</p>
            <p class="lead" style="color:#4f4f4f">
            如此  才能让心态轻松一些，因为  我们既然活着，就得好好的匆匆而过。 </p>
           <p class="lead" style="color:#4f4f4f">
             一张照片，忘记炫耀，记录真情，返璞归真</p>
          </div>
        </div>
	  </div>
    </div>
    <!-- /About -->
        <!-- Portfolio -->
    <div id="portfolio" class="portfolio">
    <div class="container">
    <div class="row push50">
          <div class="col-md-4 col-md-offset-4 text-center">
            <h2 style="color:black">推荐·图片</h2>
  <h3>
      <a class="filter label label-default" href="./content/index.html" target="_blank">我的照片</a>
      <a class="filter label label-default" href="./masterphotoes/index.html" target="_blank">大师作品</a>
      <a class="filter label label-default" href="./wallpapers/index.html" target="_blank">高清壁纸</a>
      <a class="filter label label-default" href="../luntan/" target="_blank">我要上传</a>
  </h3>
            <hr>
          </div>
        </div>
<link rel="stylesheet" href="css/baguettebox.min.css">
<link rel="stylesheet" href="css/zzsc.css">
<script src="js/baguettebox.min.js"></script>
<div class="baguetteBoxOne gallery">
        <a href="img/1-1.jpg" data-caption="Golden Gate Bridge"><img src="img/thumbs/1-1.jpg"></a>
        <a href="img/1-2.jpg" title="Midnight City"><img src="img/thumbs/1-2.jpg"></a>
        <a href="img/1-3.jpg"><img src="img/thumbs/1-3.jpg"></a>
        <a href="img/1-4.jpg"><img src="img/thumbs/1-4.jpg"></a>
        <a href="img/1-5.jpg"><img src="img/thumbs/1-5.jpg"></a>
        <a href="img/1-6.jpg"><img src="img/thumbs/1-6.jpg"></a>
        <a href="img/1-7.jpg"><img src="img/thumbs/1-7.jpg"></a>
        <a href="img/1-8.jpg"><img src="img/thumbs/1-8.jpg"></a>
        <a href="img/1-1.jpg" data-caption="Golden Gate Bridge"><img src="img/thumbs/1-1.jpg"></a>
        <a href="img/1-2.jpg" title="Midnight City"><img src="img/thumbs/1-2.jpg"></a>
        <a href="img/1-3.jpg"><img src="img/thumbs/1-3.jpg"></a>
        <a href="img/1-4.jpg"><img src="img/thumbs/1-4.jpg"></a>
        <a href="img/1-5.jpg"><img src="img/thumbs/1-5.jpg"></a>
        <a href="img/1-6.jpg"><img src="img/thumbs/1-6.jpg"></a>
        <a href="img/1-7.jpg"><img src="img/thumbs/1-7.jpg"></a>
        <a href="img/1-8.jpg"><img src="img/thumbs/1-8.jpg"></a>

        </div>
<script>
baguetteBox.run('.baguetteBoxOne', {
    animation: 'fadeIn',
});
</script>       

  
    </div>  
      </div>
    <!-- Services -->
    <div id="services" class="services">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4 text-center">
            <h2>摄影·学堂</h2>
            <hr>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 text-center">
            <div class="service-item">
              <i class="service-icon fa fa-camera-retro fa-3x"></i>
              <h3><a href="http://academy.fengniao.com/list_968.html" target="_blank" style="text-decoration:none;">摄影技巧</a></h3>
              <p>Ad has dicat ridens consetetur, eos eu option persius. Mollis cotidieque conclusionemque per id, ne nam alienum liberavisse. </p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
			<i class="service-icon fa fa-camera fa-3x"></i>
              <h3><a href="http://academy.fengniao.com/list_969.html" target="_blank" style="text-decoration:none;">后期秘籍</a></h3>
              <p>In mea similique vulputate, ea cum amet malorum dissentiunt. Qui deleniti aliquando cu, ullum soluta his an, id inani salutatus sit.</p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
              <i class="service-icon fa fa-globe fa-3x"></i>
              <h3><a href="http://product.fengniao.com/" target="_blank" style="text-decoration:none;">器材选购</a></h3>
              <p>Ad has dicat ridens consetetur, eos eu option persius. Mollis cotidieque conclusionemque per id, ne nam alienum liberavisse.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /Services -->


    <!-- /Portfolio -->
    <!-- Contact -->
    <div id="contact">
      <div class="container">
        <div class="row">
		<div class="col-md-4 col-md-offset-4 text-center">
            <h2>给我·留言</h2>
			<hr>
          </div>
          <div class="col-md-5 col-md-offset-3">
		  <!-- contact form starts -->
            <form action="contact.php" method="post"  class="form-horizontal">
			<fieldset>
						    <div class="form-group">
						      <label class="col-sm-4 control-label" for="name">你的名字</label>
						      <div class="col-sm-8">
						        <input type="text"  placeholder="Your Name" class="form-control" name="name" id="name">
						      </div>
						    </div>
						    <div class="form-group">
						      <label class="col-sm-4 control-label" for="email">邮箱</label>
						      <div class="col-sm-8">
						        <input type="text" placeholder="Enter Your Email" class="form-control" name="email" id="email">
						      </div>
						    </div>
						    <div class="form-group">
						      <label class="col-sm-4 control-label" for="subject">地址</label>
						      <div class="col-sm-8">
						        <input type="text" placeholder="Address" class="form-control" name="address" id="address">
						      </div>
						    </div>
						    <div class="form-group">
						      <label class="col-sm-4 control-label" for="message">内容</label>
						      <div class="col-sm-8">
						        <textarea placeholder="Please Type Your Message" class="form-control" name="message" id="message" rows="3"></textarea>
						      </div>
						    </div>
	              <div class="col-sm-offset-4 col-sm-8">
			            <button type="submit" class="btn btn-success">发送留言</button>
	    			      <a href="../jiaoben3850/index.php" class="btn btn-primary" target="_blank" ">查看留言</a>
	        			</div>
						</fieldset>
						</form>
				
				<!-- contact form ends -->		
          </div>
        </div>
      </div>
    </div>
    <!-- /Contact -->
    <!-- Footer -->
    <footer>
    <div >
<!--     <div style="float: left;">
    <h5>友情链接：<a href="https://6k3o.com/" style="text-decoration:none;" target="_blank">6k&3o</a> </h5>    
    </div> -->
    <div style="float: center;">    
     <h4>
             <a href="javascript:;" id="ClickMe" style="text-decoration:none;">打赏</a>


             </h4>
        </div> 
    </div>

   <div style="display: none;" id="goodcover"></div>
  
<div style="display: none;"  id="code">
  <div class="close1"><a href="javascript:void(0)" id="closebt"><img src="img/close.gif"></a></div>
  <div class="goodtxt">
    <p>扫一扫</p>
    <p>支持我做得更好</p>
    <p>我会带来更多高清壁纸哦~</p>
  </div>
  <div class="code-img"> <img id="ewmsrc"  src="img/code.jpg"></div>
</div>
    

    <script>
$(function() {
    //alert($(window).height());
    $('#ClickMe').click(function() {
        $('#code').center();
        $('#goodcover').show();
        $('#code').fadeIn();
    });
    $('#closebt').click(function() {
        $('#code').hide();
        $('#goodcover').hide();
    });
  $('#goodcover').click(function() {
        $('#code').hide();
        $('#goodcover').hide();
    });
    /*var val=$(window).height();
  var codeheight=$("#code").height();
    var topheight=(val-codeheight)/2;
  $('#code').css('top',topheight);*/
    jQuery.fn.center = function(loaded) {
        var obj = this;
        body_width = parseInt($(window).width());
        body_height = parseInt($(window).height());
        block_width = parseInt(obj.width());
        block_height = parseInt(obj.height());

        left_position = parseInt((body_width / 2) - (block_width / 2) + $(window).scrollLeft());
        if (body_width < block_width) {
            left_position = 0 + $(window).scrollLeft();
        };

        top_position = parseInt((body_height / 2) - (block_height / 2) + $(window).scrollTop());
        if (body_height < block_height) {
            top_position = 0 + $(window).scrollTop();
        };

        if (!loaded) {

            obj.css({
                'position': 'fixed'
            });
            obj.css({
                'top': ($(window).height() - $('#code').height()) * 0.5,
                'left': left_position
            });
            $(window).bind('resize', function() {
                obj.center(!loaded);
            });
            $(window).bind('scroll', function() {
                obj.center(!loaded);
            });

        } else {
            obj.stop();
            obj.css({
                'position': 'fixed'
            });
            obj.animate({
                'top': top_position
            }, 200, 'linear');
        }
    }

})
</script>

     <h6> &copy; 2016 · 20LD.top · 鄂ICP证16024636号&nbsp&nbsp    
     友情链接：<a href="https://6k3o.com/" style="text-decoration:none;" target="_blank">6k&3o</a>  </h6>

     <h6>         
     <?php
         $txt_db = 'count.txt';
         $nums = file_get_contents($txt_db);
         $nums++;
         file_put_contents($txt_db,$nums);         
        ?>
          
     </h6>
<!--       <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3 text-center">
           

             
 
          </div>
        </div>
      </div> -->

    </footer> 
    <!-- /Footer -->
    <!-- Bootstrap core JavaScript -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-scrolltofixed-min.js"></script>
	<script src="js/jquery.vegas.js"></script>
	<script src="js/jquery.mixitup.min.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/bootstrap.js"></script>
	
<!-- Slideshow Background  -->
	<script>
$.vegas('slideshow', {
  delay:5000,
  backgrounds:[
     { src:'./img/nature1.jpg', fade:2000 },
	 { src:'./img/bw1.jpg', fade:2000 },
    { src:'./img/portrait1.jpg', fade:2000 },
	 { src:'./img/portrait5.jpg', fade:2000 },
    { src:'./img/portrait2.jpg', fade:2000 },
    { src:'./img/portrait3.jpg', fade:2000 },
	 { src:'./img/portrait4.jpg', fade:2000 },
	   { src:'./img/forest.jpg', fade:2000 }
	   
  ]
})('overlay', {
src:'./img/overlay.png'
});

	</script>
<!-- /Slideshow Background -->

<!-- Mixitup : Grid -->
    <script>
		$(function(){
    $('#Grid').mixitup();
      });
    </script>
<!-- /Mixitup : Grid -->	

    <!-- Custom JavaScript for Smooth Scrolling - Put in a custom JavaScript file to clean this up -->
    <script>
      $(function() {
        $('a[href*=#]:not([href=#])').click(function() {
          if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
            || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
            if (target.length) {
              $('html,body').animate({
                scrollTop: target.offset().top
              }, 1000);
              return false;
            }
          }
        });
      });
    </script>
<!-- Navbar -->
<!-- /Navbar-->
	
  </body>

</html>