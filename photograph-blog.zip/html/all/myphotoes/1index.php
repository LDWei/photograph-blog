﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>摄影|时间-我的照片</title>
<link rel="stylesheet" href="css/baguettebox.min.css">
<link rel="stylesheet" href="css/zzsc.css">
<script src="js/baguettebox.min.js"></script>
<link rel="stylesheet" href="css/main.css" />
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
</head>
<body style="">

        <div class="baguetteBoxOne gallery">
<?php
// echo $_GET['cat_id'];
     $di="./".$_GET['cat_id'];
     $dir ="./".$_GET['cat_id2'];
    if (is_dir($dir)) {   
    if ($dh = opendir($dir)) {   
        while (($file = readdir($dh)) !== false) {   
            if ($file!="." && $file!=".." ) {   
                    echo '<a href="'.$di.'/'.$file.'"> <img src="'.$dir.'/'.$file.'"/>';
            }   
        }   
        closedir($dh);   
    }   
} 
?>
</div>
<center>
<div>
<script>
baguetteBox.run('.baguetteBoxOne', {
    animation: 'fadeIn',
});
</script>

</body>
</html>