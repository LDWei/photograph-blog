<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
    <link rel="icon" href="./images/logo.ico" type="image/x-icon"/>
<title>摄影|时间</title>


<link type="text/css" rel="stylesheet" href="css/style.css" />

</head>
<body>

<header class="site__header island">
  <div class="wrap">
   <span id="animationSandbox" style="display: block;"><h1 class="site__title mega">摄影 | 时间</h1></span>
    <span class="beta subhead">welcome to photograph|time</span>
  </div>
</header><!-- /.site__header -->
<a class="butt" style="text-decoration:none;"
      href="./all/index.php" >开始吧</a>
      <br><br>

<h5 style="color: #7b8993;">         
<?php
         $txt_db = './all/count.txt';
         $nums = file_get_contents($txt_db);
         $nums++;
         file_put_contents($txt_db,$nums);
         echo "访问次数：$nums";
        ?>
        	
        </h5>
</body>
</html>
