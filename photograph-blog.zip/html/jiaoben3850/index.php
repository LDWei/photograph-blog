

<?php
require('./lib/init.php');
$sql= "select Message,cdate from person order by cdate DESC";
$liuy = mGetAll($sql);
require(ROOT . './1index.php');