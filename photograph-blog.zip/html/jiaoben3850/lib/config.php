<?php

return array(
'host'=>'localhost',
'user'=>'root',
'pwd'=>'111111',
'db'=>'contact',
'charset'=>'utf8'
);

?>