<?php 
function mConn() {
	static $conn = null;
	if($conn === null) {
		$cfg = require(ROOT . '/lib/config.php');
		$conn = mysql_connect($cfg['host'] , $cfg['user'] , $cfg['pwd']);
		mysql_query('use '.$cfg['db'] , $conn);
		mysql_query('set names '.$cfg['charset'] , $conn);
	}

	return $conn;
}

/**
* 查询的函数
* @return mixed resoure/bool
*/
function mQuery($sql) {
	$rs  = mysql_query($sql , mConn());
	return $rs;
}
/**
* select 查询多行数据
*
* @param str $sql select 待查询的sql语句
* @return mixed select 查询成功,返回二维数组,失败返回false
*/

function mGetAll($sql) {
	$rs = mQuery($sql);
	if(!$rs) {
		return false;
	}

	$data = array();
	while($row = mysql_fetch_assoc($rs)) {
		$data[] = $row;
	}

	return $data;
}